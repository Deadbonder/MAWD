from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from typing import Optional, List
import time

app = FastAPI()

#Task1 Data pydantic Model 
class Todo(BaseModel):
    id: Optional[int]  # optional
    task: str
    is_completed: bool = False

todo_db = []
current_id = 1

#Create of CRUD
@app.post("/todos", response_model=Todo)
def create_todo(item: Todo):
    global current_id
    item.id = current_id  
    current_id += 1  
    todo_db.append(item) #adding to db
    return item

#Read of CRUD
@app.get("/todos/{item_id}", response_model=Todo)
def get_todo(item_id: int):
    for item in todo_db:
        if item.id == item_id:
            return item
    raise HTTPException(status_code=404, detail="Todo item not found")

@app.get("/todos", response_model=List[Todo])
def get_all_todos():
    return todo_db

#Update of CRUD
@app.put("/todos/{item_id}", response_model=Todo)
def update_todo(item_id: int, updated_item: Todo):
    for index, item in enumerate(todo_db):
        if item.id == item_id:
            todo_db[index] = updated_item
            updated_item.id = item_id  #same id
            return updated_item
    raise HTTPException(status_code=404, detail="Todo item not found")

# delete of CRUD

@app.delete("/todos/{item_id}")
def delete_todo(item_id: int):
    for index, item in enumerate(todo_db):
        if item.id == item_id:
            del todo_db[index]
            return {"message": f"Todo item with ID {item_id} has been deleted"}
    raise HTTPException(status_code=404, detail="Todo item not found")

# Root endpoint
@app.get("/")
def root():
    return {"message": "Welcome to the ToDo API!"}

# health check endpoint
@app.get("/health")
def health():
    return {"status": "ok"}

# Middleware 
@app.middleware("http")
async def add_custom_headers(request: Request, call_next):
    start_time = time.time()  
    response = await call_next(request) 
    process_time = time.time() - start_time  
    response.headers["X-Custom-Header"] = "FastAPI-demo"  
    response.headers["X-Process-Time"] = str(process_time)  
    return response