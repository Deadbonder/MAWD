from fastapi import FastAPI, HTTPException, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List
from db import get_db_connection, init_db

app = FastAPI()

# Initialize the database
init_db()


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],  
    allow_headers=["*"],  
)


templates = Jinja2Templates(directory="templates")

# Pydantic models
class User(BaseModel):
    username: str
    password: str

class Book(BaseModel):
    id: int
    title: str
    author: str
    year: int

# Registration API
@app.post("/register")
def register(user: User):
    conn = get_db_connection()
    try:
        conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (user.username, user.password))
        conn.commit()
    except Exception as e:
        if "UNIQUE constraint failed" in str(e):
            raise HTTPException(status_code=400, detail="Username already exists")
        else:
            raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        conn.close()
    return {"message": "User registered successfully"}

# Login API 
@app.post("/login")
def login_form(username: str = Form(...), password: str = Form(...)):
    conn = get_db_connection()
    cursor = conn.execute("SELECT password FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    if row and row["password"] == password:
        return {"message": "Login successful", "username": username}
    raise HTTPException(status_code=401, detail="Invalid username or password")



# 1. List all books
@app.get("/books", response_model=List[Book])
def list_books():
    conn = get_db_connection()
    cursor = conn.execute("SELECT * FROM books")
    books = cursor.fetchall()
    conn.close()
    return [dict(book) for book in books]

# 2. Get a single book by ID
@app.get("/books/{id}", response_model=Book)
def get_book(id: int):
    conn = get_db_connection()
    cursor = conn.execute("SELECT * FROM books WHERE id = ?", (id,))
    book = cursor.fetchone()
    conn.close()
    if book:
        return dict(book)
    raise HTTPException(status_code=404, detail="Book not found")

# 3. Create a new book
@app.post("/books", response_model=Book)
def create_book(book: Book):
    conn = get_db_connection()
    try:
        conn.execute(
            "INSERT INTO books (id, title, author, year) VALUES (?, ?, ?, ?)",
            (book.id, book.title, book.author, book.year)
        )
        conn.commit()
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail="Book with this ID already exists")
    conn.close()
    return book

# 4. Update book data
@app.put("/books/{id}", response_model=Book)
def update_book(id: int, book: Book):
    conn = get_db_connection()
    cursor = conn.execute("SELECT * FROM books WHERE id = ?", (id,))
    existing_book = cursor.fetchone()
    if not existing_book:
        conn.close()
        raise HTTPException(status_code=404, detail="Book not found")
    conn.execute(
        "UPDATE books SET title = ?, author = ?, year = ? WHERE id = ?",
        (book.title, book.author, book.year, id)
    )
    conn.commit()
    conn.close()
    return book

# 5. Delete a book
@app.delete("/books/{id}")
def delete_book(id: int):
    conn = get_db_connection()
    cursor = conn.execute("SELECT * FROM books WHERE id = ?", (id,))
    existing_book = cursor.fetchone()
    if not existing_book:
        conn.close()
        raise HTTPException(status_code=404, detail="Book not found")
    conn.execute("DELETE FROM books WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return {"message": "Book deleted successfully"}


@app.get("/books/html", response_class=HTMLResponse)
def get_books_html(request: Request):
    conn = get_db_connection()
    cursor = conn.execute("SELECT * FROM books")
    books = cursor.fetchall()
    conn.close()
    return templates.TemplateResponse("books.html", {"request": request, "books": books})


@app.get("/books/{id}/html", response_class=HTMLResponse)
def get_book_html(request: Request, id: int):
    conn = get_db_connection()
    cursor = conn.execute("SELECT * FROM books WHERE id = ?", (id,))
    book = cursor.fetchone()
    conn.close()
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    return templates.TemplateResponse("book_detail.html", {"request": request, "book": book})


@app.get("/login/html", response_class=HTMLResponse)
def get_login_html(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/test-template", response_class=HTMLResponse)
def test_template(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})