def count_words(filename):
  
    word_count = {}
    try:
        with open(filename, 'r') as file:
            for line in file:
                # Normalize the text (convert to lowercase and remove punctuation)
                words = line.strip().lower().replace('.', '').replace(',', '').split()
                for word in words:
                    word_count[word] = word_count.get(word, 0) + 1
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
    return word_count

def print_top_words(word_count, top_n=3):
   
    total_words = sum(word_count.values())
    sorted_words = sorted(word_count.items(), key=lambda x: x[1], reverse=True)
    top_words = {word: count for word, count in sorted_words[:top_n]}
    print('total number of wrods in file:', total_words)
    print("top 3 most frequent words:", top_words)
    return

# Main program
if __name__ == "__main__":
    filename = "data.txt"
    word_count = count_words(filename)
    result = print_top_words(word_count)
    print(result)  