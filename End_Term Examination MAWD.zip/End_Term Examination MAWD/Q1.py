marks = [67, 89, 45, 92, 56, 78, 88, 90, 45, 67]

#part 1 , remove all duplicates
unique_marks = list(set(marks))
print("list with no duplicates:", unique_marks)

#part 2 , sort the marks in decending order 
unique_marks.sort(reverse=True)
print("Marks in descending order:", unique_marks)

# Part 3
highest = max(unique_marks)
lowest = min(unique_marks)
average = sum(unique_marks) / len(unique_marks)

print("Highest mark:", highest)
print("Lowest mark:", lowest)
print("Average mark:", average)

#Part 4 storing in dictionary
marks_dict = {
    "highest": highest,
    "lowest": lowest,
    "average": average
}

print("MARKS SUMMARY:", marks_dict)
